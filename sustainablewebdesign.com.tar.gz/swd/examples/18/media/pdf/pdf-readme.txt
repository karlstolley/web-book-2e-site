The pdf/ folder should contain all of the .pdf (Portable Document Folder) files for a project.
