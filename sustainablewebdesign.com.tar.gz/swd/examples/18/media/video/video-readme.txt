The video/ folder should contain all of the video files for a project.
