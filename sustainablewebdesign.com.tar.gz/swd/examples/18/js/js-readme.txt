The js/ folder should contain all of the .js files for a project.

The jquery/ sub-folder contains the jQuery JavaScript Library.

The swfobject/ sub-folder contains SWFObject.
