The share folder should contain any thumbnail images and favicons for sharing site content.

