The pdf folder should contain all of the .pdf files for a project.

