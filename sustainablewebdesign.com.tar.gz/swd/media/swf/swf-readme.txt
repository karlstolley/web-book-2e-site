The swf folder should contain all of the .swf (Flash) files for a project.

