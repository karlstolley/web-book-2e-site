The audio folder should contain all of the audio files for a project.

