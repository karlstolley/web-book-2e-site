The media folder should contain all of the meda files--audio, images, PDFs, Flash movies, video--for a project. Each media type has its own sub-folder.

The share sub-folder is for keeping track of any share thumbnails and favicons, or other site-wide assets for sharing.

